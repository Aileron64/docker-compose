#!/bin/bash
#
# Copyright (c) 2009-2020. Authors: see NOTICE file.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

bash write_logs_to_file.sh

path=$( cd "$(dirname "${BASH_SOURCE}")" ; pwd -P )
cd $path

#sh create_docker_images.sh
echo "clean containers"
sh clean_docker_keep_data.sh > /dev/null
echo "launch new containers"
sh start_deploy.sh

sh backup_database.sh

